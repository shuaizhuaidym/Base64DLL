extern "C" int Base64decode_len(const char *bufcoded);

extern "C" int Base64decode(char *bufplain, const char *bufcoded);

extern "C" int Base64encode_len(int len);

extern "C" int Base64encode(char *encoded, const char *string, int len);
